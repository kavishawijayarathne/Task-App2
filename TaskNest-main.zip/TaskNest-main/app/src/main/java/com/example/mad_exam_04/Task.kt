package com.example.mad_exam_04

data class Task(val id: Int, val title: String, val content: String)
